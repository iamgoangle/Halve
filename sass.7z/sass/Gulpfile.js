/**
 * @author  Teerapong Singthong
 * @date    06/27/2016
 * if you need to start compiling Sass in to CSS file by manually from cli you
 * you can type this command $ gulp sass
 *
 * if you need automatically compiling by watcher just typing $ gulp
 */

var gulp = require('gulp');
var sass = require('gulp-ruby-sass');
var mininfyCSS = require('gulp-clean-css');
var rename = require('gulp-rename');

/* create sass task */
gulp.task('sass', function () {
    return sass('sass/*.scss', {
        style: 'expanded'
    })
    .on('error', sass.logError)
    .pipe(gulp.dest('result'));
});

/* create mininfy css task */
gulp.task('minify-css', function() {
    return gulp.src('result/*.css')
    .pipe(mininfyCSS(
        {
            debug: true,
            keepBreaks: false
        }, function(details) {
        console.log(details.name + ': ' + details.stats.originalSize);
        console.log(details.name + ': ' + details.stats.minifiedSize);
    }))
    .pipe(rename({ suffix: '.min' }))
    .pipe(gulp.dest('dist'));
});

/* create watcher */
gulp.task('watch', function(){
    gulp.watch('sass/*.scss', ['sass'], function (){
        //console.log('[Sass task] is done.');
    });

    gulp.watch('result/*.css', ['minify-css'], function (){
        //console.log('[Minify CSS] task is done.');
    });
});

/* default task */
gulp.task('default', ['sass', 'watch', 'minify-css']);
